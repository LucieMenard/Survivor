# Ce fichier a pour but d'aider le lancement du jeu

Ce jeu a été développé dans le cadre des cours d'initiation à un projet informatique de l'ENIB au deuxième semestre.
La contrainte du jeu était une balle avec des rebonds.

Pour lancer le jeu :
Dezipper le dossier
Ouvrir un terminal et l'aggrandir
Rentrer dans le dossier
Lancer le fichier "main.py" avec python 2.7
Suivre les instructions
Amuser vous bien !

Lucie Ménard, S2P-C, l7menard@enib.fr
